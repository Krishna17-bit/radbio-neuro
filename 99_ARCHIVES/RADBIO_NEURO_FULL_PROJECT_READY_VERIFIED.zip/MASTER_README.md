# Radiation-to-Biology-to-Neural-Risk Modelling Pipeline

This project builds a clean, reproducible research-product pipeline linking radiation space environments to biological cellular effects and neural circuit risk projections.

## Project Architecture

The pipeline consists of the following consecutive layers:

### 1. Physics Layer (`RADBIO_NEURO_001`)
- **Objective**: Load and process SPENVIS environment data to calculate absorbed tissue doses and dose-rates under different shielding thicknesses.
- **Key Inputs**: SPENVIS output files (Scenario A: ISS-like LEO; Scenario B: Van Allen/RBSP-like crossing).
- **Key Outputs**: `biology_ready_dose_forcing_table.csv` containing mission absorbed doses (Gy) and daily dose rates (mGy/day) for shielding depths (1, 2, 5, 10, 20 mm Al).
- **Scientific Caveat**: SPENVIS effective-dose Monte Carlo files contain NaN values. Consequently, SHIELDOSE-2 tissue absorbed dose is utilized as the canonical physics input.

### 2. Biology Calibration Layer (`RADBIO_NEURO_002`)
- **Objective**: Simulate daily cellular dynamics (Reactive Oxygen Species [ROS], mitochondrial integrity, and ATP levels) driven by absorbed dose-rate forcing, and calibrate parameters against scientific literature targets.
- **Key Inputs**: `biology_ready_dose_forcing_table.csv` and `validation_targets.csv` (literature anchors, e.g. Acharya et al., eNeuro 2019).
- **Key Outputs**: Calibrated model parameters (`calibrated_parameters.json`), endpoint and daily timecourse CSV tables, and figures showing mitochondrial/redox responses.
- **Mathematical Splitting**: Explicitly separates fast redox (ROS/channel) effects from slow bioenergetic (mitochondrial/ATP) decay.

### 3. Neural Simulation Layer (`RADBIO_NEURO_003`)
- **Objective**: Translate biological cellular states into functional neural tissue effects using a leaky integrate-and-fire (LIF) network.
- **Key Inputs**: Calibrated biology endpoint predictions and daily timecourses.
- **Key Outputs**: Population firing rates, voltage traces, and raster plots for healthy control, LEO, and VAB scenarios at different shielding depths.
- **Functional Coupling**: Fast ROS delta adds transient excitation, while slow ATP suppression reduces membrane time constants, shifts thresholds upward, and diminishes baseline driving currents.

### 4. Dashboard and API Product Layer (`RADBIO_NEURO_PRODUCT`)
- **Objective**: Provide an interactive web dashboard and FastAPI interface for research exploration, scenario stress-testing, and automated report generation.
- **Components**:
  - Streamlit dashboard (`05_PRODUCT_DASHBOARD_API/streamlit_app.py`) for visualization of scenarios, shielding depths, biological courses, and neural rasters.
  - FastAPI backend (`05_PRODUCT_DASHBOARD_API/api.py`) exposing processed data points.
