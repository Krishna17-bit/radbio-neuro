# Model Card: ROS/Mito & Neural LIF Scaffolds

This card describes the parameters, design, and calibration targets of the biological and neural simulation models.

## Model Details

- **Model Type**: Bounded cellular kinetic dynamics coupled to a stochastic Leaky Integrate-and-Fire (LIF) network.
- **Components**:
  - **Biology Scaffold**: Sublinear ROS induction, chronic mitochondrial damage, slow mitochondrial repair, and excitability/LTP proxy calculations.
  - **Neural Network**: Pure numpy-based LIF population simulation (conductance-aware equivalent).
- **Intended Use**: Research exploration and educational/pipeline software demonstration.
- **Unintended Use**: Medical diagnosis, clinical prognosis, space flight operational planning, or astronaut shielding certification.

## Model Equations

### 1. Cellular Kinetics
$$\frac{dR}{dt} = (1 - e^{-\alpha \dot{D}}) (1 - R) - k_{\text{scav}} R$$
$$\frac{dM}{dt} = k_{\text{repair}} (1 - M) - k_{\text{damage}} \dot{D} (1 + k_{\text{amp}} R) M$$
$$\text{ATP} = M^{\gamma_{\text{atp}}}$$

Where:
- $\dot{D}$ is the normalized dose-rate forcing index: $\dot{D} = \frac{\text{dose\_rate}}{\text{ref\_dose\_rate}}$.
- $R$ is normalized ROS [0.0 - 1.0].
- $M$ is mitochondrial integrity [0.0 - 1.0].

### 2. LIF Network Dynamics
Each neuron $j$ updates membrane voltage $V_j$:
$$dV_j = \frac{dt}{\tau_{\text{eff}}} \left( (V_{\text{rest}} - V_j) + \text{drive}_{\text{eff}} \right) + \eta_j \sqrt{\frac{dt}{\tau_{\text{eff}}}}$$

Where:
- $\tau_{\text{eff}} = \frac{\tau_m}{1 + g_{\text{leak}} (1 - \text{ATP})}$
- $V_{\text{threshold,eff}} = V_{\text{threshold}} + \Delta V_{\text{threshold}} (1 - \text{ATP})$
- $\text{drive}_{\text{eff}} = \text{drive}_{\text{baseline}} (0.08 + 0.92 \text{ATP}) + G_{\text{ros}} \Delta_{\text{excitability}}$
- $\eta_j$ is Gaussian noise scaled by $\text{noise}_{\text{eff}}$.

## Calibration & Validation Targets

The biology parameters are calibrated using lightweight random search against these validation targets:
1. `NEURO_CHRONIC_NEUTRON_EXCITABILITY_18cGy_180d`
   - Target variable: `excitability_ratio`
   - Target ratio to control: 0.8
   - Exposure: 1.0 mGy/day for 180 days
   - Reference: Acharya et al., eNeuro 2019
2. `NEURO_CHRONIC_NEUTRON_LTP_18cGy_180d`
   - Target variable: `ltp_proxy`
   - Target ratio to control: 0.75
   - Exposure: 1.0 mGy/day for 180 days
   - Reference: Acharya et al., eNeuro 2019

## Core Limitations
- **No LET Weighting**: The physics model uses absorbed Gray (Gy) instead of biologically-equivalent Sievert (Sv) due to SPENVIS Monte Carlo NaN issues.
- **Sparsity of Validation Data**: Chronic space radiation biology studies are rare; fitting is anchored to only two mouse endpoints.
- **Extrapolation**: Projections for dose rates outside [0.1, 10.0] mGy/day are not biologically validated and are flagged as severe extrapolations.
