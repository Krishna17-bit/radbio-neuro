# Scientific Limitations & Warnings

This modeling pipeline is a computational research tool, not a clinical diagnosis or astronaut health management system. The following list details the core scientific limitations, data gaps, and extrapolation caveats that must be considered by users.

## 1. Effective-Dose Monte Carlo NaN Outputs
- **Observation**: The SPENVIS Monte Carlo (Mulassis) outputs in the raw data files for LEO (10k, 100k) and VAB (10k) contain `NaN` values for the integrated effective-dose equivalent fields.
- **Action**: These Monte Carlo results are flagged as unusable. They are audited but **not** utilized as inputs to any biological or neural simulation layer.
- **Remediation**: The Monte Carlo calculations need to be rerun with verified configurations or replaced by standard codes (e.g., OLTARIS, HZETRN) to resolve reliable Sievert (Sv) values.

## 2. SHIELDOSE-2 Absorbed Dose Input
- **Decision**: Because Monte Carlo dose-equivalent values are unavailable, **SHIELDOSE-2 tissue absorbed dose** (Gy over 180 days) is used as the sole physical input.
- **Implication**: Absorbed dose does not account for radiation quality factors (LET/RBE) of high-energy trapped protons, GCR ions, or secondary neutrons. The actual biological damage equivalent (Sv) may be significantly higher than predicted by absorbed dose.

## 3. Provisional Biological Calibration Scaffold
- **Status**: The ROS/mitochondria/ATP kinetic model is a provisional mathematical scaffold rather than a fully validated physiological representation.
- **Calibration**: The model is fit to literature-derived approximate anchors (e.g., mouse neuroelectrophysiology data from Acharya et al., eNeuro 2019). The exact parameter values represent mathematical optimization within a scaffold rather than direct cellular measurements.

## 4. Extrapolation to Extreme Dose-Rates (Van Allen Belt)
- **Warning**: The primary biology validation data resides in the chronic low-dose-rate domain (~1.0 mGy/day). The Van Allen Belt scenario (VAB_RBSP_like) with thin shielding (>100 mGy/day) yields dose-rates orders of magnitude higher.
- **Action**: All model outputs for cases outside the [0.1, 10.0] mGy/day range are flagged with `outside_primary_validation_domain_high_dose_rate`. These projections constitute an extreme mathematical extrapolation.

## 5. Medical and Operational Disclaimer
- **CRITICAL**: This software is a computational research prototype.
- **Disclaimer**: No clinical, medical, or astronaut operational health decision-making should be based on the model or dashboard outputs.
